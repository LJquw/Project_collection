package gas;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mgr start=new Mgr();
		start.initial();
		start.startMenu();
	}

}
